package com.group47.canadadash;

public class GameStateTest {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}