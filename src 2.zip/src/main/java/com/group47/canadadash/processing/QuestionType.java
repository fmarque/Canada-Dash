package com.group47.canadadash.processing;

/**
 * Used to identify the type of question
 */
public enum QuestionType {
    fillInTheBlank, multipleChoice, trueOrFalse
}
