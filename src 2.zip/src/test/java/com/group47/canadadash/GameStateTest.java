package com.group47.canadadash;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GameStateTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getTotalPoints() {
    }

    @Test
    void decreasePoints() {
    }

    @Test
    void increasePoints() {
    }

    @Test
    void getLives() {
    }

    @Test
    void looseLife() {
    }

    @Test
    void getCheckpoints() {
    }

    @Test
    void addStar() {
    }

    @Test
    void removeStar() {
    }

    @Test
    void getLeaves() {
    }

    @Test
    void addLeaves() {
    }

    @Test
    void removeLeaf() {
    }

    @Test
    void getBoxes() {
    }

    @Test
    void addBox() {
    }

    @Test
    void removeBox() {
    }

    @Test
    void getFences() {
    }

    @Test
    void addFence() {
    }

    @Test
    void removeFence() {
    }

    @Test
    void addHole() {
    }

    @Test
    void removeHole() {
    }

    @Test
    void getHoles() {
    }

    @Test
    void setProvince() {
    }

    @Test
    void getProvince() {
    }

    @Test
    void showInventory() {
    }

    @Test
    void hasPiece() {
    }

    @Test
    void isPause() {
    }

    @Test
    void setPause() {
    }
}