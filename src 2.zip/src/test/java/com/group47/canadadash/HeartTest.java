package com.group47.canadadash;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HeartTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getX() {
    }

    @Test
    void getY() {
    }

    @Test
    void setX() {
    }

    @Test
    void setY() {
    }

    @Test
    void getHeight() {
    }

    @Test
    void getWidth() {
    }

    @Test
    void getImageAdd() {
    }

    @Test
    void move() {
    }

    @Test
    void setHeart() {
    }

    @Test
    void isFullHeart() {
    }

    @Test
    void setImageAdd() {
    }
}